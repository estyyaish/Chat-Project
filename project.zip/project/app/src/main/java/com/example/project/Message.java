package com.example.project;

import java.util.Date;

public class Message {
    public static final String USER_UI= "123456789";

    public String uid="";
    public String userUid="";
    public String userName="";
    public String text;
    public Date   date;
}